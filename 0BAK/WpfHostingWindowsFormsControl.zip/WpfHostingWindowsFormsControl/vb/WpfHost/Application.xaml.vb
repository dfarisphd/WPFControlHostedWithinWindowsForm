﻿Imports System.Configuration

Namespace WpfHost
	''' <summary>
	''' Interaction logic for App.xaml
	''' </summary>
	Partial Public Class App
        Inherits System.Windows.Application
	End Class
End Namespace
